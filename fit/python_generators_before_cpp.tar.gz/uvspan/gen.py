"""Cases for uvspan: where does the TSP start a line of a triangle when part of the line is hidden?

    python gen.py [--seed N] [--list op|tr]        ->  cases.h, cases.json

uvmeas found that the TSP evaluates a plane once per line of a triangle in a tile, at the first pixel the
triangle covers there, and steps from it (every step rounds down, so the start is visible in the values).
Here an opaque red band, nearer than the triangle, hides some columns of the cell. Is the start still the
first pixel the triangle covers (H1), or the first visible pixel of each run of the triangle's pixels (H2)?

Every cell: one textured triangle as in uvmeas --mix general (depth 1, steep U), in the opaque list with
depth test and write, and by cell number mod 4: no band / a band over the left part of the triangle / a band
in its middle / two bands. A triangle is picked, among a few random ones, for the number of pixels on which
the two hypotheses give different readings.
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent / "ops"))
sys.path.insert(0, str(HERE))
import model as M

PAGES = 8
f32 = lambda a: np.asarray(a, dtype=np.float32).astype(np.float64)


def mant(rng, bits):
    return float(rng.integers(1 << (bits - 1), 1 << bits)) / (1 << (bits - 1))


def pixels(t):
    """Pixel centers of the cell, masks: covered by the triangle, 1.5 pixels inside it, hidden by a band."""
    x, y = np.array(t["x"]), np.array(t["y"])
    cx, cy = np.floor(x.min() / 32) * 32, np.floor(y.min() / 32) * 32
    gy, gx = np.mgrid[0:32, 0:32]
    px, py = cx + gx + 0.5, cy + gy + 0.5
    X, Y = np.broadcast_to(x, (32, 32, 3)).reshape(-1, 3), np.broadcast_to(y, (32, 32, 3)).reshape(-1, 3)
    cov = M.covered(M.BASE, X, Y, px.ravel(), py.ravel()).reshape(32, 32)
    area = (x[1] - x[0]) * (y[2] - y[0]) - (x[2] - x[0]) * (y[1] - y[0])
    dist = np.full(px.shape, np.inf)
    for i in range(3):
        j = (i + 1) % 3
        ex, ey = x[j] - x[i], y[j] - y[i]
        dist = np.minimum(dist, (ex * (py - y[i]) - ey * (px - x[i])) / np.hypot(ex, ey) * np.sign(area))
    hid = np.zeros((32, 32), bool)
    for a, b in t["bands"]:
        hid[:, a:b] = True
    return px, py, cov, dist > 1.5, hid


def starts(cov, hid):
    """Per pixel: column of the first covered pixel of its line (H1), and of the first pixel of its visible run (H2)."""
    h1 = np.zeros((32, 32)); h2 = np.zeros((32, 32))
    for r in range(32):
        cols = np.nonzero(cov[r])[0]
        if len(cols) == 0:
            continue
        h1[r] = cols[0]
        run = None
        for c in range(32):
            if cov[r, c] and not hid[r, c]:
                run = c if run is None else run
                h2[r, c] = run
            else:
                run = None
    return h1, h2


def reading(t, px, py, col):
    x, y, u = (np.broadcast_to(np.array(t[k]), (px.size, 3)) for k in ("x", "y", "u"))
    w = np.ones_like(u)
    xs = np.floor(px.ravel() / 32) * 32 + col.ravel() + 0.5
    with np.errstate(all="ignore"):
        U = M.tsp_divide(M.tsp_plane(M.BASE, x, y, w, px.ravel(), py.ravel(), attr=u, xs=xs), M.tsp_plane(M.BASE, x, y, w, px.ravel(), py.ravel(), xs=xs))
        return (np.floor((U - np.floor(U)) * 1024).astype(np.int64) % 1024).reshape(px.shape)


def candidate(rng, cell):
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    ck = rng.choice(["int", "16", "float"], p=[0.25, 0.25, 0.5])
    while True:
        pts = rng.uniform(0.0, 32.0, (3, 2))
        pts = np.round(pts) if ck == "int" else np.round(pts * 16) / 16 if ck == "16" else pts
        x, y = f32(cx + pts[:, 0]), f32(cy + pts[:, 1])
        if abs((x[1] - x[0]) * (y[2] - y[0]) - (x[2] - x[0]) * (y[1] - y[0])) > 500:
            break
    m = int(rng.integers(6, 10))
    u0 = mant(rng, 24) * 2.0 ** m
    rel = 0.5 if rng.uniform() < 0.7 else 2.0 ** -int(rng.integers(2, 6))
    u = f32(u0 * (1.0 + rng.uniform(-1, 1, 3) * rel))
    lo, hi = int(pts[:, 0].min()) + 2, int(pts[:, 0].max()) - 2
    kind = cell % 4
    if kind == 0 or hi - lo < 8:
        bands, kind = [], 0
    elif kind == 1:
        bands = [[0, int(rng.integers(lo + 2, (lo + hi) // 2 + 1))]]
    elif kind == 2:
        a = int(rng.integers(lo + 2, hi - 4))
        bands = [[a, a + int(rng.integers(1, 4))]]
    else:
        a = int(rng.integers(lo + 2, (lo + hi) // 2))
        b = int(rng.integers(a + 3, hi - 1)) if a + 3 < hi - 1 else a + 3
        bands = [[a, a + 1], [b, b + 2]]
    return {"x": x.tolist(), "y": y.tolist(), "u": u.tolist(), "z": [1.0, 1.0, 1.0], "m": m, "bands": bands,
            "group": ["no band", "left band", "middle band", "two bands"][kind]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--list", default="op", choices=["op", "tr"])
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    pages, total = [], 0
    for p in range(PAGES):
        tris = []
        for cell in range(300):
            best = None
            for _ in range(4):
                t = candidate(rng, cell)
                px, py, cov, inside, hid = pixels(t)
                h1, h2 = starts(cov, hid)
                use = inside & ~hid
                n = int((reading(t, px, py, h1) != reading(t, px, py, h2))[use].sum()) if t["bands"] else int(use.sum())
                if best is None or n > best[0]:
                    best = (n, t)
            total += best[0] if best[1]["bands"] else 0
            tris.append(best[1])
        pages.append(tris)
    write(HERE, {"seed": args.seed, "list": args.list, "pages": pages})
    print(f"seed {args.seed}: {PAGES} pages, {sum(len(p) for p in pages)} triangles, {sum(len(t['bands']) for p in pages for t in p)} bands, {total} pixels on which the hypotheses differ")


def write(folder, data):
    """cases.h and cases.json from the description of a set (also used to run an archived set again).

    Every float goes into cases.h as the bit pattern of the single precision number: the test program never
    converts or calculates one, so a PC and the console send the same bits."""
    pages = data["pages"]
    fl = lambda v: "0x%08xu" % int(np.float32(v).view(np.uint32))
    lines = ["/* Generated by gen.py - do not edit. Floats are bit patterns. */", "#include <stdint.h>", f"#define NUM_TRIS {sum(len(p) for p in pages)}",
             f"#define LIST_TR {int(data.get('list', 'op') == 'tr')}",
             "typedef struct { unsigned char page; uint32_t v[3][4]; } tri_t;   /* x, y, u, z */", "static const tri_t tris[NUM_TRIS] = {"]
    bands = []
    for p, tris in enumerate(pages):
        for cell, t in enumerate(tris):
            v = ", ".join("{ " + ", ".join(fl(q) for q in (t["x"][k], t["y"][k], t["u"][k], t["z"][k])) + " }" for k in range(3))
            lines.append("    { %d, { %s } }," % (p, v))
            bands += [(p, cell, a, b) for a, b in t["bands"]]
    lines += ["};", f"#define NUM_BANDS {len(bands)}", "typedef struct { unsigned char page; short cell, a, b; } band_t;   /* columns a .. b-1 of the cell */",
              "static const band_t bands[NUM_BANDS] = {"] + ["    { %d, %d, %d, %d }," % b for b in bands] + ["};"]
    (folder / "cases.h").write_bytes((chr(10).join(lines) + chr(10)).encode())
    (folder / "cases.json").write_text(json.dumps(data))


if __name__ == "__main__":
    main()
