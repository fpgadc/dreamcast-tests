"""Cases for covmeas: which pixels does the ISP take as inside a triangle, when an edge passes (almost)
exactly through pixel centers?

    python gen.py [--seed N] [--mix lattice|tile|axis|diag|skew|lean|leantile]
                  [--prim tri|strip|sprite|modvol|zprobe] [--list op|tr|pt] [--halfofs N]        ->  cases.h, cases.json

--prim: what carries the triangle's edges. tri: a triangle of its own (the default). strip: a strip of two
triangles, the triangle and a second one across its edge v1 v2. sprite: a sprite whose first three corners are
the triangle's. modvol: the triangle is a modifier volume of its own in front of a white polygon with cheap
shadow, and darkens what it covers.
zprobe: the triangle is red and writes its depth (1.0); a green polygon over the whole screen at depth 0.5 with
compare GREATER follows. Red: drawn. Green: the ISP did not cover the pixel. Black: the ISP covered it (the depth
is there and rejects the green polygon) but nothing was shaded.
--list: the list the polygons go to (opaque, translucent, punch-through).
--halfofs N: the HALF_OFFSET register (default 7). With bit 0 clear the ISP samples at pixel corners, and the
special edges are moved by half a pixel to pass through those.

Every cell has one white triangle. One of its edges runs along a lattice direction (p, q), small coprime
integers, through a pixel center P0, so that it passes through the centers P0 + k (p, q) as well: up to a
handful of pixels per triangle whose edge function is zero or a few units of the last bit away from it. What
the console draws there shows how it rounds the edge function. Kinds:
    exact      vertices on the line, as float32 allows (the line misses the centers by rounding only)
    ulp        as exact, with coordinates moved by a few units of their last bit
    sixteenth  vertices on the 1/16 pixel grid and exactly on the line: the edge function is exactly zero at
               the centers in real arithmetic, and the tie rule decides
The vertex order (which edge is the special one) and the winding are random.

--mix axis / diag: only horizontal and vertical (or only 45 degree) lattice edges, kind exact: the simplest
cases, many of them.
--mix skew: horizontal and vertical lattice edges whose ends are moved across the line by a few units of the
last bit: one slope is tiny against the other.
--mix lean: one edge is nearly horizontal (or nearly vertical) and spans most of the tile, some reaching past its
first or last pixel; it leans by anything from a quarter of the last kept bit of its slope to 1 pixel in 16. Its
height is chosen with the model (ops/model.py) so that the edge function is close to zero somewhere on the row:
either at the tile's first column (the whole row is then decided at once) or further along.
--mix leantile: the same with triangles of 3x3 cells, the edge crossing two tile borders.
--mix sliver: the third corner is 0.00001 to 0.05 pixel off the lattice edge (or exactly on it): triangles whose
area is at or below what the setup's products resolve, so the determinant, and with it the winding, may come out
zero or with the wrong sign.
--mix degen: exactly degenerate triangles: a corner repeated (A A B, A B B, A B A), all three the same, or three
corners exactly on one line (on the 1/16 grid, in any order); the line mostly a lattice line through pixel
centers. With --prim strip the degenerate triangle is one of a strip's two (A A B C, A B C C, C A B A) or both
(A B B C), the way strips are joined.
--mix tiny: three corners within 1 unit of the last place to 0.1 pixel of one point (a pixel center, or anywhere):
almost a point. The constants of its edges are then pure rounding, and whether it draws nothing or whole rows of
its tile depends on how they fall.
--mix big: triangles with two corners far outside the screen (40 to 30000 pixels), in the cells along the screen's
border: a wedge that opens outward from a corner inside the cell, one side along a lattice direction through pixel
centers. The products of the setup are large here and lose whole pixels' worth of the edge function.
--mix tile: triangles of several cells' size, the lattice edge crossing tile borders (is the edge function
evaluated per tile from a start value, as the depth is?).
"""
import argparse
import json
from math import gcd
from pathlib import Path

import sys

import numpy as np

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent / "ops"))
import model as M
PAGES = 8
f32 = lambda a: np.asarray(a, dtype=np.float32).astype(np.float64)
DIRS = [(p, q) for p in range(-5, 6) for q in range(0, 6) if (p, q) != (0, 0) and gcd(abs(p), abs(q)) == 1 and (q > 0 or p > 0)]


CENTER = 0.5        # where the ISP samples a pixel: 0.5, or 0 with HALF_OFFSET bit 0 clear


def ulp_move(rng, v, k):
    # np.int32(...): with numpy 1 the sum of an int32 and a Python int is an int64
    return float(np.int32(np.float32(v).view(np.int32) + int(rng.integers(-k, k + 1))).view(np.float32))


def triangle(rng, cell, span, dirs=DIRS, kinds=(0.4, 0.3, 0.3), skew=0):
    """span: the size of the region the triangle may use, in cells (1: inside its own cell)."""
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    W = 32.0 * span
    kind = rng.choice(["exact", "ulp", "sixteenth"], p=kinds)
    for _ in range(1000):
        p, q = dirs[int(rng.integers(len(dirs)))]
        P0 = np.array([cx + int(rng.integers(4, W - 4)) + CENTER, cy + int(rng.integers(4, W - 4)) + CENTER])
        d = np.array([p, q], float)
        if kind == "sixteenth":
            s1, s2 = (int(rng.integers(8, 16 * 16 * span)) / 16.0 for _ in range(2))
        else:
            s1, s2 = rng.uniform(0.6, 12.0 * span, 2)
        a, b = P0 - s1 * d, P0 + s2 * d
        n = np.array([-q, p], float) / np.hypot(p, q) * rng.choice([-1, 1])
        c = (a + b) / 2 + rng.uniform(-0.4, 0.4) * (b - a) + n * rng.uniform(7, 24 * span)
        if kind == "sixteenth":
            c = np.round(c * 16) / 16
        pts = np.stack([a, b, c])
        if (pts[:, 0] < cx + 0.25).any() or (pts[:, 0] > cx + W - 0.25).any() or (pts[:, 1] < cy + 0.25).any() or (pts[:, 1] > cy + W - 0.25).any():
            continue
        if np.hypot(*(b - a)) < 5:
            continue
        pts = f32(pts)
        if kind == "ulp":
            for i in range(2):
                for j in range(2):
                    if rng.uniform() < 0.6:
                        pts[i, j] = ulp_move(rng, pts[i, j], 3)
        if skew:            # an axis-aligned edge with its ends a few units of the last bit off the line
            j = 1 if q == 0 else 0
            for i in range(2):
                if rng.uniform() < 0.75:
                    pts[i, j] = ulp_move(rng, pts[i, j], skew)
            kind = "skew"
        order = rng.permutation(3)
        return {"x": pts[order, 0].tolist(), "y": pts[order, 1].tolist(), "group": kind, "dir": [p, q], "p0": P0.tolist(),
                "edge": [int(np.nonzero(order == 0)[0][0]), int(np.nonzero(order == 1)[0][0])]}
    raise RuntimeError("no triangle")


def lean_triangle(rng, cell, span=1):
    """A triangle with a nearly axis-aligned edge along a row (or a column) of pixel centers. `along` is the
    coordinate the edge runs along, `across` the other one."""
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    W = 32.0 * span
    for _ in range(400):
        vert = rng.uniform() < 0.35
        o_al, o_ac = (cy, cx) if vert else (cx, cy)
        j = int(rng.integers(2, W - 2))
        lo = rng.uniform(0.27, 0.48) if rng.uniform() < 0.25 else rng.uniform(0.6, 7.0)
        hi = W - (rng.uniform(0.26, 0.48) if rng.uniform() < 0.3 else rng.uniform(0.6, 7.5))
        a_al, b_al = (float(v) for v in f32([o_al + lo, o_al + hi]))
        ac0 = o_ac + j + CENTER
        ulp = float(np.spacing(np.float32(ac0)))
        G = 2.0 ** (int(np.frexp(b_al - a_al)[1]) - 21)
        lean = float(np.exp(rng.uniform(np.log(0.25), np.log(4000.0)))) * G * rng.choice([-1, 1])
        k = int(np.round(lean / ulp)) or int(rng.choice([-1, 1]))
        side = int(rng.choice([-1, 1]))
        far = ac0 + side * rng.uniform(6.0, min(22.0 * span, (j - 0.5) if side < 0 else (W - j - 1.5)) if (j - 0.5 if side < 0 else W - j - 1.5) > 6.5 else 6.4)
        if far < o_ac + 0.3 or far > o_ac + W - 0.3:
            continue
        c_al = rng.uniform(o_al + lo + 2.0, o_al + hi - 2.0)
        order = rng.permutation(3)
        want_row = rng.uniform() < 0.4          # the tile's first column on the row close to zero
        ms = rng.permutation(np.arange(-60, 61))
        best = None
        for m in ms[:80]:
            pa, pb = ac0 + m * ulp, ac0 + (m + k) * ulp
            pts = np.array([[a_al, pa], [b_al, pb], [c_al, far]])
            if vert:
                pts = pts[:, ::-1]
            pts = f32(pts)
            x, y = pts[order, 0][None], pts[order, 1][None]
            ia, ib = int(np.nonzero(order == 0)[0][0]), int(np.nonzero(order == 1)[0][0])
            if (ib - ia) % 3 != 1:
                ia, ib = ib, ia
            area = (x[0, 0] - x[0, 2]) * (y[0, 1] - y[0, 2]) - (y[0, 0] - y[0, 2]) * (x[0, 1] - x[0, 2])
            sg = -1.0 if area > 0 else 1.0
            # the model's edge value along the row (column) of the edge, in the tile next to the edge's low end
            n = 32
            if vert:
                qx, qy = np.full(n, cx + j + CENTER), cy + np.arange(n) + CENTER
            else:
                qx, qy = cx + np.arange(n) + CENTER, np.full(n, cy + j + CENTER)
            S, sx, sy, ii, jj, _ = M.edge_values(M.BASE, np.full(n, x[0, ia]), np.full(n, y[0, ia]), np.full(n, x[0, ib]), np.full(n, y[0, ib]), qx, qy, CENTER)
            v = sg * (S + sx * ii + sy * jj)
            if not np.isfinite(v).all():
                continue
            if vert:
                good = np.abs(v).min() <= 150
            elif want_row:
                good = abs(v[0]) <= 70
            else:
                good = abs(v[0]) > 64 and np.abs(v[2:30]).min() <= 64
            cand = (pts, ia, ib)
            if good:
                best = cand
                break
            if best is None and np.abs(v).min() <= 400:
                best = cand
        if best is None:
            continue
        pts, ia, ib = best
        P0 = [cx + j + CENTER, cy + 16 + CENTER] if vert else [cx + 16 + CENTER, cy + j + CENTER]
        return {"x": pts[order, 0].tolist(), "y": pts[order, 1].tolist(), "group": "lean-v" if vert else "lean-h", "dir": [0, 1] if vert else [1, 0],
                "p0": P0, "edge": [ia, ib]}
    raise RuntimeError("no triangle")


def sliver_triangle(rng, cell):
    """A lattice edge through pixel centers and a third corner almost on it."""
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    kind = rng.choice(["exact", "ulp", "sixteenth"], p=[0.4, 0.2, 0.4])
    for _ in range(1000):
        p, q = DIRS[int(rng.integers(len(DIRS)))]
        P0 = np.array([cx + int(rng.integers(4, 28)) + CENTER, cy + int(rng.integers(4, 28)) + CENTER])
        d = np.array([p, q], float)
        if kind == "sixteenth":
            s1, s2 = (int(rng.integers(8, 16 * 16)) / 16.0 for _ in range(2))
        else:
            s1, s2 = rng.uniform(0.6, 12.0, 2)
        a, b = P0 - s1 * d, P0 + s2 * d
        n = np.array([-q, p], float) / np.hypot(p, q) * rng.choice([-1, 1])
        delta = 0.0 if rng.uniform() < 0.1 else 10.0 ** rng.uniform(-5.0, -1.3)
        c = a + rng.uniform(0.1, 0.9) * (b - a) + n * delta
        pts = np.stack([a, b, c])
        if (pts[:, 0] < cx + 0.25).any() or (pts[:, 0] > cx + 31.75).any() or (pts[:, 1] < cy + 0.25).any() or (pts[:, 1] > cy + 31.75).any():
            continue
        if np.hypot(*(b - a)) < 5:
            continue
        pts = f32(pts)
        if kind == "ulp":
            for i in range(2):
                for j in range(2):
                    if rng.uniform() < 0.6:
                        pts[i, j] = ulp_move(rng, pts[i, j], 3)
        order = rng.permutation(3)
        return {"x": pts[order, 0].tolist(), "y": pts[order, 1].tolist(), "group": "sliver-" + kind, "dir": [p, q], "p0": P0.tolist(),
                "edge": [int(np.nonzero(order == 0)[0][0]), int(np.nonzero(order == 1)[0][0])]}
    raise RuntimeError("no triangle")


def degen_triangle(rng, cell, strip):
    """Corners of an exactly degenerate triangle (or of a strip of two triangles with one in it)."""
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    kind = str(rng.choice(["dup01", "dup12", "dup02", "point", "line"], p=[0.2, 0.2, 0.2, 0.1, 0.3]))
    for _ in range(1000):
        p, q = DIRS[int(rng.integers(len(DIRS)))]
        d = np.array([p, q], float)
        P0 = np.array([cx + int(rng.integers(6, 26)) + CENTER, cy + int(rng.integers(6, 26)) + CENTER])
        if rng.uniform() < 0.25:        # off the pixel centers
            P0 = P0 + rng.integers(-7, 8, 2) / 16.0
        s = np.sort(rng.integers(-12 * 8, 12 * 8 + 1, 3)) / 8.0        # eighths: the middle of two is on the 1/16 grid
        a, b = P0 + s[0] * d, P0 + s[2] * d
        mid = (a + b) / 2 if rng.uniform() < 0.5 else P0 + s[1] * d
        n = np.array([-q, p], float) / np.hypot(p, q) * rng.choice([-1, 1])
        far = np.round(((a + b) / 2 + rng.uniform(-0.3, 0.3) * (b - a) + n * rng.uniform(7, 20)) * 16) / 16
        pts = {"a": a, "b": b, "m": mid, "c": far}
        if any((v[0] < cx + 0.3 or v[0] > cx + 31.7 or v[1] < cy + 0.3 or v[1] > cy + 31.7) for v in pts.values()) or np.hypot(*(b - a)) < 4:
            continue
        if strip:
            order = str(rng.choice(["aabc", "abcc", "abbc", "caba", "abmc", "camb"]))
            group = "strip " + order
        else:
            order = {"dup01": "aab", "dup12": "abb", "dup02": "aba", "point": "aaa", "line": str(rng.choice(["amb", "abm", "mab", "bma"]))}[kind]
            group = "degenerate " + order
        cs = f32(np.array([pts[ch] for ch in order]))
        return {"x": cs[:, 0].tolist(), "y": cs[:, 1].tolist(), "group": group, "dir": [p, q], "p0": P0.tolist(), "edge": [0, 1]}
    raise RuntimeError("no triangle")


def tiny_triangle(rng, cell):
    """Three corners almost at one point."""
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    P = np.array([cx + int(rng.integers(3, 29)) + CENTER, cy + int(rng.integers(3, 29)) + CENTER])
    if rng.uniform() < 0.5:
        P = P + rng.uniform(-0.5, 0.5, 2)
    P = f32(P)
    if rng.uniform() < 0.5:         # a few units of the last place apart
        k = int(rng.choice([1, 2, 4, 16, 64]))
        pts = np.array([[ulp_move(rng, P[0], k), ulp_move(rng, P[1], k)] for _ in range(3)])
        group = f"tiny, within {k} ulp"
    else:
        r = 10.0 ** rng.uniform(-5.0, -1.0)
        pts = f32(P + rng.uniform(-r, r, (3, 2)))
        group = "tiny, within 1e%d px" % int(np.ceil(np.log10(r)))
    return {"x": pts[:, 0].tolist(), "y": pts[:, 1].tolist(), "group": group, "dir": [1, 0], "p0": [float(P[0]), float(P[1])], "edge": [0, 1]}


BORDER = [(c, (0, -1)) for c in range(20)] + [(280 + c, (0, 1)) for c in range(20)] +          [(20 * r, (-1, 0)) for r in range(1, 14)] + [(20 * r + 19, (1, 0)) for r in range(1, 14)]


def big_triangle(rng, cell, out):
    """A wedge from a corner inside the border cell `cell` outward (out: the unit vector to the outside)."""
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    out = np.array(out, float)
    tan = np.array([-out[1], out[0]])
    kind = rng.choice(["exact", "ulp"], p=[0.6, 0.4])
    for _ in range(4000):
        def direction():
            o, t = int(rng.integers(1, 8)), int(rng.integers(-7, 8))
            return None if abs(t) > o or gcd(o, abs(t)) != 1 else o * out + t * tan
        d1, d2 = direction(), direction()
        if d1 is None or d2 is None or abs(d1[0] * d2[1] - d1[1] * d2[0]) < 1e-9:
            continue
        r, along = int(rng.integers(8, 29)), int(rng.integers(5, 27))      # of P0: pixels from the border, and along it
        if out[1] != 0:
            P0 = np.array([cx + along + CENTER, cy + (r if out[1] < 0 else 31 - r) + CENTER])
        else:
            P0 = np.array([cx + (r if out[0] < 0 else 31 - r) + CENTER, cy + along + CENTER])
        corner = np.array([cx, cy]) + np.where(out > 0, 32.0, 0.0)          # a point of the cell's outer side
        A = P0 - d1 * (int(rng.integers(0, 24)) / 16.0) / np.abs(d1).max()
        B = P0 + d1 * int(np.exp(rng.uniform(np.log(40.0), np.log(30000.0))) / np.hypot(*d1) + 1)
        C = A + d2 * np.exp(rng.uniform(np.log(40.0), np.log(30000.0))) / np.hypot(*d2)
        pts = f32(np.stack([A, B, C]))
        lo, hi = np.array([cx, cy]) + 0.3, np.array([cx, cy]) + 31.7
        if (pts[0] < lo).any() or (pts[0] > hi).any():
            continue
        ok = True
        for far in (pts[1], pts[2]):        # where the side leaves the cell through its outer side
            k = (np.dot(corner - pts[0], out)) / np.dot(far - pts[0], out)
            if not 0 < k < 1:
                ok = False
                break
            e = pts[0] + k * (far - pts[0])
            ok &= bool(np.dot(e, np.abs(tan)) > np.dot(lo, np.abs(tan)) + 0.5 and np.dot(e, np.abs(tan)) < np.dot(hi, np.abs(tan)) - 0.5)
        if not ok:
            continue
        if kind == "ulp":
            for i in range(2):
                for j in range(2):
                    if rng.uniform() < 0.6:
                        pts[i, j] = ulp_move(rng, pts[i, j], 3)
        order = rng.permutation(3)
        return {"x": pts[order, 0].tolist(), "y": pts[order, 1].tolist(), "group": "big-" + kind, "dir": [float(d1[0]), float(d1[1])], "p0": P0.tolist(),
                "edge": [int(np.nonzero(order == 0)[0][0]), int(np.nonzero(order == 1)[0][0])]}
    raise RuntimeError("no big triangle")


def fourth(rng, t, cell, span, prim):
    """The fourth corner. strip: across the edge v1 v2 from v0. sprite: v0 + v2 - v1 (a parallelogram), moved a
    little. None when it does not fit into the cell."""
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    W = 32.0 * span
    p = np.array([t["x"], t["y"]]).T
    cross = lambda a, b: a[0] * b[1] - a[1] * b[0]
    for scale in (1.0, 0.75, 0.5, 0.35, 0.2):
        if prim == "strip":
            m = (p[1] + p[2]) / 2
            d = m + scale * (m - p[0]) + rng.uniform(-1.5, 1.5, 2) * scale
        else:
            d = p[0] + scale * (p[2] - p[1]) + rng.uniform(-1.0, 1.0, 2)
        d = f32(d)
        if not (cx + 0.3 <= d[0] <= cx + W - 0.3 and cy + 0.3 <= d[1] <= cy + W - 0.3):
            continue
        if prim == "sprite":        # convex, the same way round at every corner, and no corner nearly straight
            q = np.vstack([p, d])
            cr = [cross(q[(k + 1) % 4] - q[k], q[(k + 2) % 4] - q[(k + 1) % 4]) for k in range(4)]
            if not (all(c > 4 for c in cr) or all(c < -4 for c in cr)):
                continue
        elif abs(cross(p[2] - p[1], d - p[1])) < 8 or cross(p[1] - p[0], p[2] - p[0]) * cross(p[2] - p[1], d - p[1]) > 0:
            continue                # the second triangle must lie across the edge
        return [float(d[0]), float(d[1])]
    return None


def main():
    global CENTER
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--mix", default="lattice", choices=["lattice", "tile", "axis", "diag", "skew", "lean", "leantile", "big", "sliver", "degen", "tiny"])
    ap.add_argument("--prim", default="tri", choices=["tri", "strip", "sprite", "modvol", "zprobe"])
    ap.add_argument("--list", default="op", choices=["op", "tr", "pt"])
    ap.add_argument("--halfofs", type=int, default=7)
    ap.add_argument("--probez", type=float, default=0.5, help="zprobe: the depth of the green polygon")
    ap.add_argument("--cull", default="none", choices=["none", "small", "ccw", "cw"])
    ap.add_argument("--z", type=float, default=1.0, help="the depth of the polygons")
    ap.add_argument("--zs", default="", help="three depths, one per corner of a triangle (tri and zprobe), e.g. 0.2,0.5,0.8")
    ap.add_argument("--vcol", default="", choices=["", "flat", "gouraud"], help="corners red, green, blue; flat or Gouraud shaded (tri)")
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    CENTER = 0.5 if args.halfofs & 1 else 0.0
    plain = {"lattice": lambda c: triangle(rng, c, 1),
             "axis": lambda c: triangle(rng, c, 1, [(1, 0), (0, 1)], (1.0, 0.0, 0.0)),
             "skew": lambda c: triangle(rng, c, 1, [(1, 0), (0, 1)], (1.0, 0.0, 0.0), skew=int(rng.choice([1, 2, 4, 12]))),
             "diag": lambda c: triangle(rng, c, 1, [(1, 1), (-1, 1)], (1.0, 0.0, 0.0)),
             "lean": lambda c: lean_triangle(rng, c),
             "big": lambda c: big_triangle(rng, *c),
             "sliver": lambda c: sliver_triangle(rng, c),
             "degen": lambda c: degen_triangle(rng, c, args.prim == "strip"),
             "tiny": lambda c: tiny_triangle(rng, c),
             "tile": lambda c: triangle(rng, c, 3),
             "leantile": lambda c: lean_triangle(rng, c, 3)}[args.mix]
    span = 3 if "tile" in args.mix else 1

    def make(cell):
        for _ in range(200):
            t = plain(cell)
            if args.prim in ("tri", "modvol", "zprobe") or args.mix == "degen":
                return t
            d = fourth(rng, t, cell, span, args.prim)
            if d is not None:
                t["x"].append(d[0]); t["y"].append(d[1])
                return t
        raise RuntimeError("no fourth corner")

    cells = [(3 * r) * 20 + 3 * c for r in range(5) for c in range(6)] if span == 3 else BORDER if args.mix == "big" else list(range(300))
    pages = [[make(cell) for cell in cells] for p in range(PAGES)]
    write(HERE, {"seed": args.seed, "mix": args.mix, "prim": args.prim, "list": args.list, "halfofs": args.halfofs, "probez": args.probez, "cull": args.cull, "z": args.z, "zs": args.zs, "vcol": args.vcol, "pages": pages})
    print(f"seed {args.seed} mix {args.mix} prim {args.prim} list {args.list} halfofs {args.halfofs}: {PAGES} pages, {sum(len(p) for p in pages)} triangles")


def write(folder, data):
    """cases.h and cases.json from the description of a set (also used to run an archived set again).

    Every float goes into cases.h as the bit pattern of the single precision number, so that the test
    program never converts or calculates one: a PC and the console then send the same bits."""
    pages = data["pages"]
    prim, lst, halfofs = data.get("prim", "tri"), data.get("list", "op"), data.get("halfofs", 7)
    fl = lambda v: "0x%08xu" % int(np.float32(v).view(np.uint32))
    zs = (data.get("zs") or ",".join([str(data.get("z", 1.0))] * 3)).split(",")
    lines = ["/* Generated by gen.py - do not edit. Floats are bit patterns. */", "#include <stdint.h>",
             f"#define NUM_TRIS {sum(len(p) for p in pages)}",
             f"#define COV_PRIM {['tri', 'strip', 'sprite', 'modvol', 'zprobe'].index(prim)}",
             f"#define COV_LIST {dict(op='ListType_Opaque', tr='ListType_Translucent', pt='ListType_Punch_Through')[lst]}",
             f"#define COV_HALFOFS {halfofs}", f"#define COV_PROBE_Z {fl(data.get('probez', 0.5))}",
             f"#define COV_CULL {dict(none='CullMode_None', small='CullMode_Small', ccw='CullMode_Negative', cw='CullMode_Positive')[data.get('cull', 'none')]}",
             f"#define COV_Z {fl(data.get('z', 1.0))}",
             "#define COV_ZS { %s }" % ", ".join(fl(float(v)) for v in zs),
             f"#define COV_VCOL {['', 'flat', 'gouraud'].index(data.get('vcol', ''))}",
             "typedef struct { unsigned char page; uint32_t v[4][2]; } tri_t;", "static const tri_t tris[NUM_TRIS] = {"]
    for p, tris in enumerate(pages):
        for t in tris:
            k4 = list(range(len(t["x"]))) + [0] * (4 - len(t["x"]))
            lines.append("    { %d, { %s } }," % (p, ", ".join("{ %s, %s }" % (fl(t["x"][k]), fl(t["y"][k])) for k in k4)))
    lines.append("};")
    (folder / "cases.h").write_bytes((chr(10).join(lines) + chr(10)).encode())
    (folder / "cases.json").write_text(json.dumps(data))


if __name__ == "__main__":
    main()
