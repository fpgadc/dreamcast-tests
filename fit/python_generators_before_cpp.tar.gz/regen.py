"""Write a test's cases.h and cases.json from an archived set (fit/<test>_data/<set>.cases.json).

    python3 regen.py <test> <set> [folder, default: the test's own]

run2.sh <test>@<set> calls this with the run's folder. The test's gen.py has write(folder, data)."""
import importlib.util
import json
import sys
from pathlib import Path

HERE = Path(__file__).parent
test, name = sys.argv[1], sys.argv[2]
folder = Path(sys.argv[3]) if len(sys.argv) > 3 else HERE / test
sys.path.insert(0, str(HERE / test))
spec = importlib.util.spec_from_file_location(f"{test}_gen", HERE / test / "gen.py")
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)
data = json.loads((HERE / f"fit/{test}_data/{name}.cases.json").read_text())
gen.write(folder, data)
print(f"{test} {name}: tables written from the archive")
