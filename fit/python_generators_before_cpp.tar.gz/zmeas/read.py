"""Turn the zmeas dumps into measured depths.

    python read.py [folder, default /tmp/pvr_tests/zmeas] [hw | emu | off]      ->  meas.json next to the dumps

hw: a console's dumps; emu: the emulator's screenshots; off: the dumps of refsw2-offline (meas.off.json).

For every case and pixel: "lo", the largest stored depth of the probe that did not exceed A's (A's stored depth
is at least this), and "hi", the smallest that did (A's is below this). When they are neighbours on the 19 bit
grid, A's stored depth is known exactly: it is lo. The probe's stored depth at each pixel comes from the model
(see gen.py).
"""
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent / "ops"))
sys.path.insert(0, str(HERE))        # first, so that "gen" is this folder's and not ops/gen.py
import gen as G
import model as M


def load(d, page, kind):
    if kind in ("hw", "off"):
        a = np.fromfile(d / f"page{page}.{kind}.raw", dtype="<u4").reshape(480, 640)
        return np.stack([(a >> 16) & 255, (a >> 8) & 255, a & 255], axis=-1).astype(int)
    return np.asarray(Image.open(d / f"page{page}.emu.png").convert("RGB")).astype(int)


def steps(lo, hi):
    """How many 19 bit steps hi is above lo."""
    e = np.frexp(lo)[1]
    return int(round((hi - lo) / np.ldexp(1.0, e - 19)))


def main():
    args = [a for a in sys.argv[1:] if a not in ("hw", "emu", "off")]
    kind = "emu" if "emu" in sys.argv else "off" if "off" in sys.argv else "hw"
    d = Path(args[0]) if args else Path("/tmp/pvr_tests/zmeas")
    # the run's own tables (run2.sh zmeas@<set>), else the ones in the test's folder
    data = json.loads(((d / "cases.json") if (d / "cases.json").exists() else (HERE / "cases.json")).read_text())
    cases = data["cases"]
    P = len(cases[0]["ladder"])
    ims = [load(d, p, kind) for p in range(P)]
    out, stats = [], {}
    for c in cases:
        res = []
        for n, (px, py) in enumerate(c["pixels"]):
            if G.quad_tri(c["cell"], px, py) is None:
                continue
            bvals = G.quad_depth(M.BASE, c["cell"], px, py, c["ladder_in"])     # the probe's stored depth here, per page
            g = [bool(ims[p][int(py), int(px), 1] > 128) for p in range(P)]       # green: B > A
            r = [bool(ims[p][int(py), int(px), 0] > 128) for p in range(P)]
            lo = hi = None
            mono = all(a or b for a, b in zip(g, r))
            for k in np.argsort(bvals):
                if g[k]:
                    hi = float(bvals[k]) if hi is None else hi
                else:
                    if hi is not None:
                        mono = False
                    lo = float(bvals[k])
            res.append({"px": px, "py": py, "lo": lo, "hi": hi, "monotone": mono})
        probe = res[0]
        exact = probe["lo"] is not None and probe["hi"] is not None and steps(probe["lo"], probe["hi"]) == 1 and probe["monotone"]
        delta = None
        if exact:
            e = np.frexp(c["predicted"])[1]
            delta = int(round((probe["lo"] - c["predicted"]) / np.ldexp(1.0, e - 19)))
        out.append({"probe": {**probe, "exact": exact, "delta": delta}, "pixels": res})
        s = stats.setdefault(c["group"], {"n": 0, "exact": 0, "zero": 0, "deltas": [], "bad": 0, "below": 0, "above": 0})
        s["n"] += 1
        s["exact"] += exact
        s["bad"] += not probe["monotone"]
        s["below"] += probe["lo"] is None
        s["above"] += probe["hi"] is None
        if exact:
            s["zero"] += delta == 0
            s["deltas"].append(delta)
    (d / ("meas.json" if kind == "hw" else f"meas.{kind}.json")).write_text(json.dumps({"cases": out}))
    print(f"{dict(hw='console', emu='emulator', off='refsw2-offline')[kind]}; ladders {'refined' if data['refined'] else 'first pass'}")
    print(f"{'group':46s} cases  exact  = model   differences from the model in 19 bit steps (count)")
    for name, s in stats.items():
        hist = ", ".join(f"{v:+d}: {s['deltas'].count(v)}" for v in sorted(set(s["deltas"])) if v != 0)
        extra = "".join(f"   [{s[k]} {t}]" for k, t in (("bad", "not monotone"), ("below", "below the ladder"), ("above", "above the ladder")) if s[k])
        print(f"{name:46s} {s['n']:5d} {s['exact']:6d} {s['zero']:8d}   {hist}{extra}")


if __name__ == "__main__":
    main()
