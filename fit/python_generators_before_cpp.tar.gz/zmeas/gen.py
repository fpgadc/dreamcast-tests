"""Cases for zmeas: measure the depth the ISP stores for a triangle, as a number.

    python gen.py [--mix first|general|zero|scene] [--seed N] [--refine meas.json]

A page draws a list of polygons "A" (red; depth always passes and is written), in order, and then one probe
"B" per measured cell: a flat quad over the whole 32x32 cell, compare GREATER. On page p, the depth of B is the
p-th value of the ladder of that cell, so the 16 pages bracket the stored depth of A between two stored depths
of B. --refine makes the ladder 16 consecutive stored values starting at the measured lower bound of each cell.

The stored depth of B comes from the model. Flat quads on cell corners are the family the model reproduces
completely (pvr_tests/precision), and the "calibration" group checks it here: there A is itself a full-cell
flat quad whose depth has at most 15 significant bits, which every product and sum of a 24 bit setup
represents exactly, so its stored depth is its depth whatever the details of the arithmetic are.

Mixes:
    first    one small triangle inside each cell; integer, 1/16 and float corners; flat, gentle and steep depth
    general  the same, weighted to sloped depth, a random probe pixel, wider depth range
    zero     small triangles whose depth plane crosses zero just outside the triangle, inside the tile: the depth
             changes exponent, and often sign, between the first pixel of the tile and the triangle
    scene    triangles of any size (corners up to 1500 pixels off the screen) drawn over each other, largest
             first; a cell measures the triangle that is on top there

(An earlier version used a huge flat triangle confined to the tile by the user tile clip as an exact probe.
On a console the clip is applied late - a polygon is clipped by the clip command that follows it - and with
padding added some tiles still come out corrupted; see ../cliptest.)
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent / "ops"))
import model as M

P = 16
LADDERS = {
    "first": [-64, -32, -16, -8, -4, -2, -1, 0, 1, 2, 3, 5, 9, 17, 33, 65],
    "general": list(range(-7, 9)),
    "scene": [-64, -16, -6, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 7, 17, 65],
    "zero": [-64, -16, -6, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 7, 17, 65],
}
SEARCH = 600
f32 = lambda a: np.asarray(a, dtype=np.float32).astype(np.float64)

GROUPS = {   # name, count, coordinates, depth
    "first": [
        ("calibration: full-cell quad, 15 bit depth", 20, "cal", "flat"),
        ("full-cell quad, upper triangle", 10, "quad0", "flat"),
        ("full-cell quad, lower triangle", 10, "quad1", "flat"),
        ("integer corners, flat, depth a power of two", 20, "int", "pow2"),
        ("integer corners, flat", 40, "int", "flat"),
        ("1/16 corners, flat", 40, "16", "flat"),
        ("float corners, flat", 40, "float", "flat"),
        ("integer corners, gentle slope", 30, "int", "gentle"),
        ("integer corners, steep", 30, "int", "steep"),
        ("float corners, gentle slope", 30, "float", "gentle"),
        ("float corners, steep", 30, "float", "steep"),
    ],
    "general": [
        ("calibration: full-cell quad, 15 bit depth", 10, "cal", "flat"),
        ("float corners, flat", 20, "float", "flat"),
        ("integer corners, steep", 30, "int", "steep"),
        ("1/16 corners, steep", 30, "16", "steep"),
        ("float corners, steep", 60, "float", "steep"),
        ("float corners, gentle slope", 40, "float", "gentle"),
        ("float corners, medium slope", 40, "float", "medium"),
        ("integer corners, medium slope", 20, "int", "medium"),
        ("float corners, depth over several octaves", 50, "float", "wide"),
    ],
    "zero": [
        ("calibration: full-cell quad, 15 bit depth", 10, "cal", "flat"),
        ("zero line next to the triangle, float corners", 200, "float", "zero"),
        ("zero line next to the triangle, integer corners", 90, "int", "zero"),
    ],
}


def depths(rng, kind, z0):
    if kind == "pow2":
        return np.full(3, 2.0 ** rng.integers(-5, 8))
    if kind == "flat":
        return np.full(3, z0)
    if kind == "gentle":
        return z0 * (1.0 + rng.uniform(-1, 1, 3) * 2.0 ** -rng.integers(8, 15))
    if kind == "medium":
        return z0 * (1.0 + rng.uniform(-1, 1, 3) * 2.0 ** -rng.integers(3, 8))
    if kind == "wide":
        return z0 * 2.0 ** rng.uniform(-6, 0, 3)
    return z0 * rng.uniform(0.25, 1.0, 3)


def interior(x, y, margin=1.0):
    """Pixel centers at least `margin` inside the triangle."""
    area = (x[1] - x[0]) * (y[2] - y[0]) - (x[2] - x[0]) * (y[1] - y[0])
    out = []
    for py in np.arange(np.floor(y.min()) + 0.5, y.max(), 1.0):
        for px in np.arange(np.floor(x.min()) + 0.5, x.max(), 1.0):
            ok = True
            for i in range(3):
                j = (i + 1) % 3
                ex, ey = x[j] - x[i], y[j] - y[i]
                d = (ex * (py - y[i]) - ey * (px - x[i])) / np.hypot(ex, ey) * np.sign(area)
                ok &= d > margin
            if ok:
                out.append((float(px), float(py)))
    return out


def quad_tri(cell, px, py):
    """The triangle of the full-cell quad (strip TL, TR, BL, BR) that holds the pixel, in rasterizer order.
    None on the diagonal."""
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    s = (px - cx) + (py - cy)
    if s == 32.0:
        return None
    if s < 32.0:
        return np.array([cx, cx + 32, cx]), np.array([cy, cy, cy + 32])
    return np.array([cx, cx + 32, cx + 32]), np.array([cy + 32, cy, cy + 32])


def quad_depth(cfg, cell, px, py, zs):
    """Stored depth of a full-cell flat quad at the pixel, for each depth in zs."""
    t = quad_tri(cell, px, py)
    n = len(zs)
    x, y = np.repeat(t[0][None, :], n, 0), np.repeat(t[1][None, :], n, 0)
    return M.isp_depth(cfg, x, y, np.repeat(np.asarray(zs)[:, None], 3, 1), np.full(n, px), np.full(n, py))


def make_cases(rng, mix):
    """One polygon per cell. Returns the probes; each carries its own polygon."""
    first = mix == "first"
    cells = rng.permutation(300)
    cases = []
    n = 0
    for name, count, coords, depth in GROUPS[mix]:
        for _ in range(count):
            cell = int(cells[n]); n += 1
            cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
            while True:
                z0 = float(np.exp(rng.uniform(np.log(0.02), np.log(200.0)))) if first else float(np.exp(rng.uniform(np.log(1e-3), np.log(1e3))))
                if coords in ("cal", "quad0", "quad1"):
                    if coords == "quad1":
                        x, y = np.array([cx, cx + 32, cx + 32]), np.array([cy + 32, cy, cy + 32])
                        pix = [(cx + 22.5, cy + 24.5)]
                    else:
                        x, y = np.array([cx, cx + 32, cx]), np.array([cy, cy, cy + 32])
                        pix = [(cx + 8.5, cy + 9.5)]
                    z = np.full(3, z0)
                    if coords == "cal":
                        m, e = np.frexp(z0)
                        z = np.full(3, np.ldexp(np.floor(m * 32768) / 32768, e))
                    z = f32(z)
                    full = [(cx + i + 0.5, cy + j + 0.5) for i in range(2, 30, 5) for j in range(2, 30, 5)
                            if (i + j + 1 != 32) and (coords == "cal" or ((i + j + 1 < 32) == (coords == "quad0")))]
                    break
                pts = rng.uniform(1.0, 31.0, (3, 2))
                if coords == "int":
                    pts = np.round(pts)
                elif coords == "16":
                    pts = np.round(pts * 16) / 16
                x, y = f32(cx + pts[:, 0]), f32(cy + pts[:, 1])
                if depth == "zero":
                    # depth = distance from a line that passes 0.05 .. 8 pixels outside the triangle
                    th = rng.uniform(0, 2 * np.pi)
                    s_ = np.cos(th) * x + np.sin(th) * y
                    z = f32(z0 / 16 * (s_ - s_.min() + float(np.exp(rng.uniform(np.log(0.05), np.log(8.0))))))
                else:
                    z = f32(depths(rng, depth, z0))
                area = abs((x[1] - x[0]) * (y[2] - y[0]) - (x[2] - x[0]) * (y[1] - y[0]))
                if area <= 150:
                    continue
                full = [p for p in interior(x, y) if (p[0] - cx) + (p[1] - cy) != 32.0]
                if len(full) >= 12:
                    if depth == "zero" and rng.uniform() < 0.5:      # the pixel nearest the zero line
                        pix = [min(full, key=lambda p: np.cos(th) * p[0] + np.sin(th) * p[1])]
                        break
                    if first:
                        gx, gy = x.mean(), y.mean()
                        pix = [min(full, key=lambda p: (p[0] - gx) ** 2 + (p[1] - gy) ** 2)]
                    else:
                        pix = [full[int(rng.integers(len(full)))]]
                    break
            rest = [p for p in full if p != pix[0]]
            if len(rest) > 23:
                rest = [rest[i] for i in np.linspace(0, len(rest) - 1, 23).astype(int)]
            cases.append({"group": name, "quad": coords == "cal", "cell": cell, "x": x.tolist(), "y": y.tolist(), "z": z.tolist(),
                          "pixels": pix + rest})
    tris = [{"quad": c["quad"], "cell": c["cell"], "x": c["x"], "y": c["y"], "z": c["z"]} for c in cases]
    return tris, cases


def make_scene(rng):
    """Triangles of all sizes drawn over each other; each cell measures the one that ends up on top of it."""
    classes = [("huge", 10, 1500.0), ("large", 20, 400.0), ("medium", 35, 150.0), ("small", 45, 60.0)]
    gy, gx = np.mgrid[0:480, 0:640]
    gx, gy = gx + 0.5, gy + 0.5
    owner = np.full((480, 640), -1)
    clean = np.zeros((480, 640), bool)
    load = np.zeros((15, 20), int)
    tris = []
    for cls, count, h in classes:
        made = 0
        while made < count:
            c = np.array([rng.uniform(0, 640), rng.uniform(0, 480)])
            pts = c + rng.uniform(-h, h, (3, 2))
            ck = rng.choice(["int", "16", "float"], p=[0.2, 0.2, 0.6])
            if ck == "int":
                pts = np.round(pts)
            elif ck == "16":
                pts = np.round(pts * 16) / 16
            x, y = f32(pts[:, 0]), f32(pts[:, 1])
            area = (x[1] - x[0]) * (y[2] - y[0]) - (x[2] - x[0]) * (y[1] - y[0])
            if abs(area) < h * h / 3:
                continue
            # the tiles its bounding box touches, on screen
            tx0, tx1 = int(np.clip(np.floor(x.min() / 32), 0, 19)), int(np.clip(np.floor(x.max() / 32), 0, 19))
            ty0, ty1 = int(np.clip(np.floor(y.min() / 32), 0, 14)), int(np.clip(np.floor(y.max() / 32), 0, 14))
            if x.max() < 0 or y.max() < 0 or x.min() >= 640 or y.min() >= 480:
                continue
            if load[ty0:ty1 + 1, tx0:tx1 + 1].max() >= 40:
                continue
            load[ty0:ty1 + 1, tx0:tx1 + 1] += 1
            dk = rng.choice(["flat", "gentle", "medium", "steep", "wide"], p=[0.15, 0.2, 0.2, 0.3, 0.15])
            z = f32(depths(rng, dk, float(np.exp(rng.uniform(np.log(1e-3), np.log(1e3))))))
            d = np.full((480, 640), np.inf)
            for i in range(3):
                j = (i + 1) % 3
                ex, ey = x[j] - x[i], y[j] - y[i]
                d = np.minimum(d, (ex * (gy - y[i]) - ey * (gx - x[i])) / np.hypot(ex, ey) * np.sign(area))
            inside = d > 1.0
            owner[inside] = len(tris)
            clean[inside] = True
            clean[(d > -1.0) & ~inside] = False
            tris.append({"quad": False, "cell": 0, "x": x.tolist(), "y": y.tolist(), "z": z.tolist(), "group": f"scene: {cls}, {ck} corners, {dk} depth",
                         "cls": cls})
            made += 1
    cases = []
    for cell in range(300):
        cx, cy = (cell % 20) * 32, (cell // 20) * 32
        o, cl = owner[cy:cy + 32, cx:cx + 32], clean[cy:cy + 32, cx:cx + 32].copy()
        jj, ii = np.mgrid[0:32, 0:32]
        cl &= (ii + jj) != 31                    # not on the diagonal of the probe quad
        ids, counts = np.unique(o[cl], return_counts=True)
        if len(ids) == 0 or ids[np.argmax(counts)] < 0 or counts.max() < 12:
            continue
        t = int(ids[np.argmax(counts)])
        rows, cols = np.nonzero(cl & (o == t))
        full = [(float(cx + c + 0.5), float(cy + r + 0.5)) for r, c in zip(rows, cols)]
        pix = [full[int(rng.integers(len(full)))]]
        rest = [p for p in full if p != pix[0]]
        if len(rest) > 23:
            rest = [rest[i] for i in np.linspace(0, len(rest) - 1, 23).astype(int)]
        tr = tris[t]
        cases.append({"group": "scene: " + tr["cls"], "detail": tr["group"], "tri": t, "quad": False, "cell": cell, "x": tr["x"], "y": tr["y"], "z": tr["z"],
                      "pixels": pix + rest})
    return tris, cases


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mix", default="first", choices=["first", "general", "zero", "scene"])
    ap.add_argument("--seed", type=int, default=1234567)
    ap.add_argument("--refine", default=None)
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    tris, cases = make_scene(rng) if args.mix == "scene" else make_cases(rng, args.mix)
    refine = json.loads(Path(args.refine).read_text()) if args.refine else None
    missed = 0
    for i, c in enumerate(cases):
        x, y, z = (np.array(c[k])[None, :] for k in "xyz")
        px, py = c["pixels"][0]
        pred = float(M.isp_depth(M.BASE, x, y, z, np.array([px]), np.array([py]))[0])
        c["predicted"] = pred
        if refine is None:
            center, offs = pred, LADDERS[args.mix]
        else:
            lo = refine["cases"][i]["probe"]["lo"]
            hi = refine["cases"][i]["probe"]["hi"]
            center, offs = (lo, list(range(P))) if lo is not None else (hi, list(range(-P, 0))) if hi is not None else (pred, LADDERS[args.mix])
        e = int(np.frexp(center)[1])
        unit = float(np.ldexp(1.0, e - 19))
        targets = [float(M.rnd(np.array([center + o * unit]), (19, "trunc"))[0]) for o in offs]
        # an input depth for B whose stored depth (by the model) is each target
        ladder_in, ladder = [], []
        for t in targets:
            base = np.float32(t).view(np.int32)
            cand = (base + np.arange(-SEARCH, SEARCH + 1)).astype(np.int32).view(np.float32).astype(np.float64)
            got = quad_depth(M.BASE, c["cell"], px, py, cand)
            hit = np.nonzero(got == t)[0]
            if len(hit):
                k = hit[np.argmin(np.abs(hit - SEARCH))]
            else:
                k = int(np.argmin(np.abs(got - t)))
                missed += 1
            ladder_in.append(float(cand[k])); ladder.append(float(got[k]))
        c["ladder_in"], c["ladder"] = ladder_in, ladder
    write(HERE, {"mix": args.mix, "seed": args.seed, "refined": refine is not None, "cases": cases}, tris)
    print(f"{args.mix} seed {args.seed}: {len(tris)} polygons, {len(cases)} measured cells, {P} pages;",
          "refined ladders" if refine else "first pass", f"; ladder targets with no exact input: {missed}")


def write(folder, data, tris=None):
    """cases.h and cases.json from the description of a set (also used to run an archived set again).

    Every float goes into cases.h as the bit pattern of the single precision number: the test program never
    converts or calculates one, so a PC and the console send the same bits. The archive holds the measured
    cells only; in a scene there are more polygons than those, which the seed gives again."""
    cases = data["cases"]
    if tris is None:
        if data.get("mix") == "scene":
            tris, again = make_scene(np.random.default_rng(data["seed"]))
            assert all(a["cell"] == b["cell"] and a["x"] == b["x"] and a["z"] == b["z"] for a, b in zip(again, cases)), "the seed does not give the archived scene"
        else:
            tris = cases
    fl = lambda v: "0x%08xu" % int(np.float32(v).view(np.uint32))
    lines = ["/* Generated by gen.py - do not edit. Floats are bit patterns. */", "#include <stdint.h>",
             f"#define NUM_TRIS {len(tris)}", f"#define NUM_PROBES {len(cases)}", f"#define LADDER {P}",
             "typedef struct { unsigned short cell; unsigned char is_quad; uint32_t v[3][3]; } tri_t;    /* x, y, z; quad is a macro on the console */",
             "typedef struct { unsigned short cell; uint32_t bz[LADDER]; } probe_t;",
             "static const tri_t tris[NUM_TRIS] = {"]
    for t in tris:
        v = ", ".join("{ " + ", ".join(fl(q) for q in (t["x"][k], t["y"][k], t["z"][k])) + " }" for k in range(3))
        lines.append("    { %d, %d, { %s } }," % (t["cell"], int(t["quad"]), v))
    lines += ["};", "static const probe_t probes[NUM_PROBES] = {"]
    for c in cases:
        lines.append("    { %d, { %s } }," % (c["cell"], ", ".join(fl(b) for b in c["ladder_in"])))
    lines.append("};")
    (folder / "cases.h").write_bytes((chr(10).join(lines) + chr(10)).encode())
    (folder / "cases.json").write_text(json.dumps(data))


if __name__ == "__main__":
    main()
