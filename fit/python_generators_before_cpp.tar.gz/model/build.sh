#!/bin/bash
# Build the standalone probes against the model's single source in nulldc3 (refsw2).
HERE=$(cd "$(dirname "$0")" && pwd)
REFSW=${REFSW:-$HOME/projects/fpgadc/nulldc3/libswirl/rend/refsw2}
for t in covprobe depthprobe tspprobe; do
  g++ -O2 -std=c++17 -Wall -I "$REFSW" "$HERE/$t.cpp" -o "$HERE/$t" && echo "built $HERE/$t" || exit 1
done
