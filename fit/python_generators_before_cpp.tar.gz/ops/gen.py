"""Generate the cases of the ops test: inputs on which changing ONE operation of the model changes what a
console would show.

    python gen.py          ->  cases.h (for main.c) and cases.json (for analyze.py)

Four kinds of case, one triangle each, inside one 32x32 cell:
    depth   the ISP depth at a probe pixel. The triangle is red; a green quad over the whole cell is drawn after it
            with compare EQUAL at a depth chosen so that the fitted model predicts "equal" at the probe pixel.
    fog     the TSP's 1/w at a probe pixel, read through the fog table (see ../tspw).
    color   a Gouraud gray at a probe pixel.
    cover   whether a probe pixel next to an edge is inside the triangle.
For every alternative of every operation (a bit more or less, another rounding direction, a reciprocal
instead of a division) the generator keeps up to PER_ALT cases where that alternative predicts something
else than the fitted model, plus controls.
"""
import json
import sys
from pathlib import Path

import numpy as np

import model as M

HERE = Path(__file__).parent
PER_ALT = 10
N = 60000
rng = np.random.default_rng(20261115)
f32 = lambda a: np.asarray(a, dtype=np.float32).astype(np.float64)


def random_triangles(n, zkind):
    cell = rng.integers(0, 300, n)
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    pts = rng.uniform(1.0, 31.0, (n, 3, 2))
    fine = rng.random(n) < 0.5
    pts = np.where(fine[:, None, None], pts, np.round(pts * 16) / 16)
    x = f32(cx[:, None] + pts[:, :, 0]); y = f32(cy[:, None] + pts[:, :, 1])
    z0 = np.exp(rng.uniform(np.log(1.02), np.log(180.0), n))
    kind = rng.integers(0, 3, n)
    gentle = 1.0 + rng.uniform(-1, 1, (n, 3)) * np.ldexp(1.0, -rng.integers(4, 16, n))[:, None]
    steep = rng.uniform(0.2, 1.0, (n, 3))
    fac = np.where((kind == 0)[:, None], 1.0, np.where((kind == 1)[:, None], gentle, steep))
    z = f32(np.clip(z0[:, None] * fac, 1.01, 250.0)) if zkind == "fog" else f32(z0[:, None] * fac * np.exp(rng.uniform(-3, 2, n))[:, None])
    return cell, x, y, z


def probe_pixel(x, y, margin):
    """The pixel at the centroid, and whether its center is at least `margin` pixels inside every edge."""
    gx, gy = x.mean(axis=1), y.mean(axis=1)
    px, py = np.floor(gx) + 0.5, np.floor(gy) + 0.5
    ok = np.ones(len(x), dtype=bool)
    area = (x[:, 1] - x[:, 0]) * (y[:, 2] - y[:, 0]) - (x[:, 2] - x[:, 0]) * (y[:, 1] - y[:, 0])
    for i in range(3):
        j = (i + 1) % 3
        ex, ey = x[:, j] - x[:, i], y[:, j] - y[:, i]
        d = (ex * (py - y[:, i]) - ey * (px - x[:, i])) / np.hypot(ex, ey) * np.sign(area)
        ok &= d > margin
    return px, py, ok & (np.abs(area) > 80)


def quad_tri_at(cell, px, py):
    """The full-cell quad's triangle (strip TL, TR, BL, BR) that contains the pixel, in rasterizer order."""
    cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
    upper = (px - cx) + (py - cy) < 32.0            # TL-TR-BL
    one = np.ones(len(cell))
    # even triangle (TL, TR, BL); odd triangle is given as (BL, TR, BR)
    x = np.where(upper[:, None], np.stack([cx, cx + 32, cx], 1), np.stack([cx, cx + 32, cx + 32], 1))
    y = np.where(upper[:, None], np.stack([cy, cy, cy + 32], 1), np.stack([cy + 32, cy, cy + 32], 1))
    return x, y


cases = []
alts = M.alternatives()
used = {}


def keep(kind, i, cell, x, y, z, extra, px, py, expect, tests):
    cases.append({"kind": kind, "cell": int(cell[i]), "x": [float(v) for v in x[i]], "y": [float(v) for v in y[i]],
                  "z": [float(v) for v in z[i]], **{k: (v[i].tolist() if hasattr(v[i], "tolist") else v[i]) for k, v in extra.items()},
                  "px": float(px[i]), "py": float(py[i]), "expect": expect, "tests": tests})


def select(kind, base_pred, alt_preds, cell, x, y, z, extra, px, py, valid, controls=30):
    """Pick cases greedily: each alternative gets up to PER_ALT cases where it disagrees with the model."""
    count = {k: 0 for k in range(len(alt_preds))}
    chosen = {}
    disagree = np.stack([(p != base_pred) & valid for p in alt_preds])        # (alts, N)
    order = np.argsort(-disagree.sum(axis=0))
    for i in order:
        ks = [k for k in range(len(alt_preds)) if disagree[k, i] and count[k] < PER_ALT]
        if not ks:
            continue
        for k in np.nonzero(disagree[:, i])[0]:
            count[int(k)] += 1
        chosen[int(i)] = [int(k) for k in np.nonzero(disagree[:, i])[0]]
    idx = np.nonzero(valid)[0]
    for i in rng.choice(idx, min(controls, len(idx)), replace=False):
        chosen.setdefault(int(i), [])
    for i, ks in chosen.items():
        keep(kind, i, cell, x, y, z, extra, px, py, int(base_pred[i]),
             {str(k): int(alt_preds[k][i]) for k in ks})
    return count


# ---- depth -------------------------------------------------------------------------------------------------
cell, x, y, z = random_triangles(N, "depth")
px, py, ok = probe_pixel(x, y, 1.5)
a_base = M.isp_depth(M.BASE, x, y, z, px, py)
qx, qy = quad_tri_at(cell, px, py)
zb = np.full(N, np.nan)
target = a_base.astype(np.float32)
for k in range(-200, 201):
    cand = np.nextafter(target, np.float32(np.inf)) if False else (target.view(np.int32) + k).view(np.float32).astype(np.float64)
    got = M.isp_depth(M.BASE, qx, qy, np.repeat(cand[:, None], 3, 1), px, py)
    hit = (got == a_base) & np.isnan(zb)
    zb[hit] = cand[hit]
valid = ok & ~np.isnan(zb) & np.isfinite(a_base) & (a_base > 0)
zq = np.repeat(np.nan_to_num(zb)[:, None], 3, 1)
base_pred = np.ones(N, dtype=int)                 # the model says: equal
depth_alts = [k for k, (name, _, _) in enumerate(alts) if not name.startswith("tsp") and name not in ("edge x product", "edge y product", "edge sum")]
preds = []
for k in depth_alts:
    cfg = alts[k][2]
    with np.errstate(all="ignore"):
        preds.append((M.isp_depth(cfg, x, y, z, px, py) == M.isp_depth(cfg, qx, qy, zq, px, py)).astype(int))
cnt = select("depth", base_pred, preds, cell, x, y, z, {"bz": zb}, px, py, valid)
for c in cases:
    if c["kind"] == "depth":
        c["tests"] = {str(depth_alts[int(k)]): v for k, v in c["tests"].items()}
print("depth: cases per alternative:", {alts[depth_alts[k]][0] + " / " + alts[depth_alts[k]][1]: v for k, v in cnt.items() if v < PER_ALT})

# negative controls: the quad one stored step away, where the model says "not equal"
n0 = len(cases)
idx = np.nonzero(valid)[0][:40]
for i in idx:
    zbi = float(np.int32(np.float32(zb[i]).view(np.int32) + 97).view(np.float32))      # np.int32: numpy 1 makes the sum an int64
    if M.isp_depth(M.BASE, qx[i:i + 1], qy[i:i + 1], np.full((1, 3), zbi), px[i:i + 1], py[i:i + 1])[0] != a_base[i]:
        cases.append({"kind": "depth", "cell": int(cell[i]), "x": x[i].tolist(), "y": y[i].tolist(), "z": z[i].tolist(), "bz": zbi,
                      "px": float(px[i]), "py": float(py[i]), "expect": 0, "tests": {}})

# ---- fog (TSP 1/w) -----------------------------------------------------------------------------------------
cell, x, y, z = random_triangles(N, "fog")
px, py, ok = probe_pixel(x, y, 1.5)
iw = M.tsp_plane(M.BASE, x, y, z, px, py)
valid = ok & (iw > 1.01) & (iw < 250)
base_pred = M.fog_readout(iw)
fog_alts = [k for k, (name, _, _) in enumerate(alts) if name in ("tsp slope coefficient", "tsp constant coefficient", "tsp line grid",
            "tsp value", "constant sum order", "slope sum order", "determinant sum order", "reciprocal", "coefficient product", "constant product", "constant sum", "slope product", "slope sum",
            "edge product", "edge constant", "determinant sum", "coordinate difference")]
preds = []
for k in fog_alts:
    with np.errstate(all="ignore"):
        preds.append(M.fog_readout(M.tsp_plane(alts[k][2], x, y, z, px, py)))
m0 = len(cases)
cnt = select("fog", base_pred, preds, cell, x, y, z, {}, px, py, valid)
for c in cases[m0:]:
    c["tests"] = {str(fog_alts[int(k)]): v for k, v in c["tests"].items()}
print("fog: cases per alternative below the target:", {alts[fog_alts[k]][0] + " / " + alts[fog_alts[k]][1]: v for k, v in cnt.items() if v < PER_ALT})

# ---- color -------------------------------------------------------------------------------------------------
cell, x, y, z = random_triangles(N, "depth")
px, py, ok = probe_pixel(x, y, 1.5)
col = rng.integers(0, 256, (N, 3)).astype(np.float64)
col[rng.random(N) < 0.3] = 255.0
base_pred = M.tsp_color(M.BASE, x, y, z, col, px, py)
valid = ok
col_alts = [k for k, (name, _, _) in enumerate(alts) if name.startswith("tsp")]
preds = []
for k in col_alts:
    with np.errstate(all="ignore"):
        preds.append(M.tsp_color(alts[k][2], x, y, z, col, px, py))
m0 = len(cases)
cnt = select("color", base_pred, preds, cell, x, y, z, {"col": col}, px, py, valid)
for c in cases[m0:]:
    c["tests"] = {str(col_alts[int(k)]): v for k, v in c["tests"].items()}
print("color: cases per alternative below the target:", {alts[col_alts[k]][0] + " / " + alts[col_alts[k]][1]: v for k, v in cnt.items() if v < PER_ALT})

# ---- coverage ----------------------------------------------------------------------------------------------
cell, x, y, z = random_triangles(4 * N, "depth")
# a probe pixel whose center is very close to the first edge: move the third vertex so that the edge v1-v2 passes
# within a tiny distance of a pixel center near its middle
mx, my = (x[:, 0] + x[:, 1]) / 2, (y[:, 0] + y[:, 1]) / 2
px, py = np.floor(mx) + 0.5, np.floor(my) + 0.5
d = np.ldexp(rng.uniform(-1, 1, len(x)), -rng.integers(6, 22, len(x)))
ex, ey = x[:, 1] - x[:, 0], y[:, 1] - y[:, 0]
ln = np.hypot(ex, ey)
# shift both edge vertices so the edge passes at signed distance d from the pixel center
off = ((ex * (py - y[:, 0]) - ey * (px - x[:, 0])) / ln) - d
x[:, 0] = f32(x[:, 0] - off * (-ey / ln)); x[:, 1] = f32(x[:, 1] - off * (-ey / ln))
y[:, 0] = f32(y[:, 0] - off * (ex / ln)); y[:, 1] = f32(y[:, 1] - off * (ex / ln))
cx, cy = (cell % 20) * 32.0, (cell // 20) * 32.0
inside_cell = ((x >= cx[:, None]) & (x <= cx[:, None] + 32) & (y >= cy[:, None]) & (y <= cy[:, None] + 32)).all(axis=1)
area = np.abs((x[:, 1] - x[:, 0]) * (y[:, 2] - y[:, 0]) - (x[:, 2] - x[:, 0]) * (y[:, 1] - y[:, 0]))
valid = inside_cell & (ln > 6) & (area > 60)
base_pred = M.covered(M.BASE, x, y, px, py).astype(int)
cov_alts = [k for k, (name, _, _) in enumerate(alts) if name in ("edge product", "edge constant", "coordinate difference", "edge x product",
            "edge y product", "edge sum", "edge block exponent", "edge unit", "edge mantissa", "edge slope pair grid", "edge add reach", "edge zero", "edge tie step")]
preds = [M.covered(alts[k][2], x, y, px, py).astype(int) for k in cov_alts]
m0 = len(cases)
cnt = select("cover", base_pred, preds, cell, x, y, z, {}, px, py, valid)
for c in cases[m0:]:
    c["tests"] = {str(cov_alts[int(k)]): v for k, v in c["tests"].items()}
print("cover: cases per alternative below the target:", {alts[cov_alts[k]][0] + " / " + alts[cov_alts[k]][1]: v for k, v in cnt.items() if v < PER_ALT})

# ---- lay out: one case per cell per page ---------------------------------------------------------------------
seen = {}
for c in cases:
    c["page"] = seen.get(c["cell"], 0)
    seen[c["cell"]] = c["page"] + 1
MAXP = 12
cases = [c for c in cases if c["page"] < MAXP]
pages = max(c["page"] for c in cases) + 1
kinds = {"depth": 0, "fog": 1, "color": 2, "cover": 3}
# Every float goes into cases.h as the bit pattern of the single precision number: the test program never
# converts or calculates one, so a PC and the console send the same bits.
lines = ["/* Generated by gen.py - do not edit. Floats are bit patterns. */", "#include <stdint.h>", f"#define OPS_PAGES {pages}", f"#define NUM_CASES {len(cases)}",
         "typedef struct { unsigned char kind, page; unsigned short cell; uint32_t v[3][3]; unsigned char col[3]; uint32_t bz; } case_t;    /* v: x, y, z */",
         "static const case_t cases[NUM_CASES] = {"]
fl = lambda v: "0x%08xu" % int(np.float32(v).view(np.uint32))
for c in cases:
    v = ", ".join("{ " + ", ".join(fl(t) for t in (c["x"][i], c["y"][i], c["z"][i])) + " }" for i in range(3))
    col = c.get("col", [0, 0, 0])
    lines.append(f"    {{ {kinds[c['kind']]}, {c['page']}, {c['cell']}, {{ {v} }}, {{ {int(col[0])}, {int(col[1])}, {int(col[2])} }}, {fl(c.get('bz', 0.0))} }},")
lines.append("};")
(HERE / "cases.h").write_text(chr(10).join(lines) + chr(10))
(HERE / "cases.json").write_text(json.dumps({"alternatives": [[a, b] for a, b, _ in alts], "cases": cases}))
print(len(cases), "cases on", pages, "pages:", {k: sum(c["kind"] == k for c in cases) for k in kinds})
