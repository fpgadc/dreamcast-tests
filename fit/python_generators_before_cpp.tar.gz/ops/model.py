"""The fitted arithmetic of the PVR2's setup unit, ISP depth and TSP planes, one named operation at a time.

Every operation takes its width and rounding from a config dict, so that a single operation can be changed
(gen.py does that to find inputs that tell the alternatives apart; analyze.py to score them on a console).
All functions are vectorized over numpy arrays of cases.

Vertices are given in the order the rasterizer gets them (v1, v2, v3). The order in which the three terms of
a sum are added matters (every add truncates) and is part of the config: "12,3" is (t1 + t2) + t3.
"""
import numpy as np

# name -> (bits, mode). mode: trunc (toward zero), floor, ceil, nearest.
BASE = {
    # setup, shared by ISP and TSP
    "edge product": (24, "trunc"),          # x_i * y_j
    "edge constant": (24, "trunc"),         # x2 y3 - x3 y2
    "coordinate difference": (24, "trunc"), # y2 - y3, x3 - x2
    "slope product": (24, "trunc"),         # z_i * (coordinate difference)
    "slope sum": (24, "trunc"),             # the two adds of a and of b
    "constant product": (24, "trunc"),      # z_i * e_i
    "constant sum": (24, "trunc"),          # the two adds of c
    "determinant sum": (24, "trunc"),       # e1 + e2 + e3
    "slope sum order": ("12,3", "order"),         # measured with pvr_tests/zmeas
    "constant sum order": ("13,2", "order"),
    "determinant sum order": ("12,3", "order"),
    "reciprocal": (24, "trunc"),            # 1 / det
    "coefficient product": (24, "trunc"),   # a * inv, b * inv, c * inv
    # ISP depth
    "isp start product": (24, "trunc"),     # a * x0, b * y0 at the tile's first pixel, a b c not yet divided
    "isp start sum": (24, "trunc"),         # (a x0 + b y0) + c
    "isp start sum order": ("12,3", "order"),
    "isp start normalise": (24, "trunc"),   # ((a x0 + b y0) + c) * inv
    "isp start grid": (20, "trunc"),        # bits below the start's exponent
    "isp slope mantissa": (20, "trunc"),
    "isp slope pair grid": (21, "trunc"),   # bits below the exponent of the larger of the two slopes
    "isp slope grid": (26, "trunc"),        # bits below the start's exponent
    "isp stored mantissa": (19, "trunc"),
    # TSP planes (measured with pvr_tests/uvmeas and wmeas)
    "tsp slope coefficient": (16, "trunc"),
    "tsp constant coefficient": (16, "trunc"),
    "tsp attribute constant sum order": ("12,3", "order"),   # the 1/w plane uses "constant sum order"
    "tsp line grid": (22, "floor"),         # bits under the tile's exponent (see tsp_plane): C, A x0, B y and the step A are rounded down to it
    "tsp value": (16, "floor"),             # the plane value at the pixel
    "tsp attribute product": (24, "trunc"), # attribute_i * (w_i * d_i): the 1/w plane's products times the attribute
    "tsp color round": (0.5, "bias"),       # floor(value + 0.5): 2,340,000 of 2,340,000 readings of pvr_tests/cmeas
    # coverage
    "edge x product": (24, "trunc"),        # (xa - xb) * Y
    "edge y product": (24, "trunc"),        # (ya - yb) * X
    "edge sum": (24, "trunc"),
    "edge block exponent": (6, "exp"),      # E = exponent of the larger slope + 6 (pvr_tests/covmeas)
    "edge unit": (20, "trunc"),             # bits under E of the unit whose half is the zero zone
    "edge mantissa": (20, "trunc"),         # the start value and the two slopes are 20 bit floats
    "edge slope pair grid": (21, "trunc"),  # bits under the exponent of the larger slope kept of both
    "edge add reach": (25, "exp"),          # dx y0 - dy x0: an operand this many exponents below the other is dropped
    "edge zero": (64, "level"),             # in units of 2^(E - 27): a value of at most this is zero
    "edge tie step": (64, "level"),         # a column step of at most this is zero when the row starts at zero
}


def rnd(v, spec):
    bits, mode = spec
    if bits >= 53:
        return v
    m, e = np.frexp(v)
    f = {"trunc": np.trunc, "floor": np.floor, "ceil": np.ceil, "nearest": np.rint}[mode]
    return np.ldexp(f(m * (1 << bits)) / (1 << bits), e)


def grid(v, e, spec):
    bits, mode = spec
    unit = np.ldexp(1.0, e - bits)
    f = {"trunc": np.trunc, "floor": np.floor, "ceil": np.ceil, "nearest": np.rint}[mode]
    return f(v / unit) * unit


def add3(t1, t2, t3, order, spec):
    if order[0] == "12,3":
        return rnd(rnd(t1 + t2, spec) + t3, spec)
    if order[0] == "13,2":
        return rnd(rnd(t1 + t3, spec) + t2, spec)
    return rnd(rnd(t2 + t3, spec) + t1, spec)


def setup_raw(cfg, x, y, val, attr=None):
    """a, b, c of the plane before the division by the determinant, and the reciprocal of the determinant.
    x, y, val: (N, 3) in rasterizer order. attr: per vertex attribute values (N, 3) for an attribute / w plane:
    every product val_i * d of the plane of val (1/w) is then multiplied by attr_i (and cut again)."""
    x1, x2, x3 = x[:, 0], x[:, 1], x[:, 2]
    y1, y2, y3 = y[:, 0], y[:, 1], y[:, 2]
    z1, z2, z3 = val[:, 0], val[:, 1], val[:, 2]
    EP, EC, CD = cfg["edge product"], cfg["edge constant"], cfg["coordinate difference"]
    e1 = rnd(rnd(x2 * y3, EP) - rnd(x3 * y2, EP), EC)
    e2 = rnd(rnd(x3 * y1, EP) - rnd(x1 * y3, EP), EC)
    e3 = rnd(rnd(x1 * y2, EP) - rnd(x2 * y1, EP), EC)
    SP, SS, SO = cfg["slope product"], cfg["slope sum"], cfg["slope sum order"]
    KP, KS = cfg["constant product"], cfg["constant sum"]
    ta = [rnd(z1 * rnd(y2 - y3, CD), SP), rnd(z2 * rnd(y3 - y1, CD), SP), rnd(z3 * rnd(y1 - y2, CD), SP)]
    tb = [rnd(z1 * rnd(x3 - x2, CD), SP), rnd(z2 * rnd(x1 - x3, CD), SP), rnd(z3 * rnd(x2 - x1, CD), SP)]
    tc = [rnd(z1 * e1, KP), rnd(z2 * e2, KP), rnd(z3 * e3, KP)]
    if attr is not None:
        AP = cfg["tsp attribute product"]
        ta = [rnd(attr[:, i] * ta[i], AP) for i in range(3)]
        tb = [rnd(attr[:, i] * tb[i], AP) for i in range(3)]
        tc = [rnd(attr[:, i] * tc[i], AP) for i in range(3)]
    a = add3(ta[0], ta[1], ta[2], SO, SS)
    b = add3(tb[0], tb[1], tb[2], SO, SS)
    c = add3(tc[0], tc[1], tc[2], cfg["constant sum order"], KS)
    det = add3(e1, e2, e3, cfg["determinant sum order"], cfg["determinant sum"])
    with np.errstate(all="ignore"):
        inv = rnd(1.0 / det, cfg["reciprocal"])
    return a, b, c, inv


def setup(cfg, x, y, val):
    """Plane coefficients A, B, C (absolute screen coordinates) for vertex values val."""
    a, b, c, inv = setup_raw(cfg, x, y, val)
    CP = cfg["coefficient product"]
    return rnd(a * inv, CP), rnd(b * inv, CP), rnd(c * inv, CP)


def isp_depth(cfg, x, y, z, px, py):
    """The depth the ISP compares and stores at the pixel whose center is (px, py).

    The depth at the first pixel of the tile is the plane before its division by the determinant, evaluated
    there and then multiplied by the reciprocal once (measured with pvr_tests/zmeas). The slopes are a * inv
    and b * inv as 20 bit floats; the two share an exponent, the larger one's, under which 21 bits are kept;
    and they are cut to the tile's grid, 26 bits under the exponent of the start."""
    a, b, c, inv = setup_raw(cfg, x, y, z)
    CP = cfg["coefficient product"]
    A, B = rnd(a * inv, CP), rnd(b * inv, CP)
    tx, ty = np.floor(px / 32) * 32, np.floor(py / 32) * 32
    SP, SS = cfg["isp start product"], cfg["isp start sum"]
    first = rnd(add3(rnd(a * (tx + 0.5), SP), rnd(b * (ty + 0.5), SP), c, cfg["isp start sum order"], SS) * inv, cfg["isp start normalise"])
    e = np.frexp(first)[1]
    start = grid(first, e, cfg["isp start grid"])
    ep = np.frexp(np.maximum(np.abs(A), np.abs(B)))[1]
    sx = grid(grid(rnd(A, cfg["isp slope mantissa"]), ep, cfg["isp slope pair grid"]), e, cfg["isp slope grid"])
    sy = grid(grid(rnd(B, cfg["isp slope mantissa"]), ep, cfg["isp slope pair grid"]), e, cfg["isp slope grid"])
    v = start + sx * (px - tx - 0.5) + sy * (py - ty - 0.5)
    return rnd(v, cfg["isp stored mantissa"])


def floor_to(t, lsb):
    """t rounded down to a multiple of lsb; a zero with a negative sign (a slope that cancelled exactly, times a
    negative reciprocal of the determinant) is one unit down."""
    return (np.floor(t / lsb) - ((t == 0) & np.signbit(t))) * lsb


def floor_bits(v, bits):
    lsb = np.ldexp(1.0, np.frexp(v)[1] - bits)
    return np.floor(v / lsb) * lsb


def span_start(cfg, x, y, px, py):
    """The center of the first pixel of the triangle on the line of (px, py) inside its tile: where the TSP
    starts the line when nothing hides the triangle. (Pixels the triangle does not cover give the tile's left
    edge.) With a nearer polygon over part of the line, every run of visible pixels of the triangle starts
    anew at its own first pixel (pvr_tests/uvspan): pass that to tsp_plane as xs."""
    tl = np.floor(px / 32) * 32
    first = np.full(np.shape(px), np.nan)
    for n in range(32):
        first = np.where(np.isnan(first) & covered(cfg, x, y, tl + n + 0.5, py), n, first)
    return tl + np.where(np.isnan(first), 0, first) + 0.5


def tsp_exp(v):
    """Exponent as frexp gives it; a zero has none."""
    return np.where(v == 0, -9999, np.frexp(v)[1])


def tsp_plane(cfg, x, y, val, px, py, attr=None, xs=None):
    """A TSP plane at the pixel whose center is (px, py): of val (1/w per vertex), or of attr * val when attr
    (per vertex attribute values) is given.

    The coefficients are the setup's, cut to 16 bit floats. They are evaluated in fixed point on one grid per
    tile, 22 bits under an exponent E: the largest of the exponent of C and of the exponents the two products
    can have in this tile, exp(A) + exp(X) - 1 and exp(B) + exp(Y) - 1 with X, Y any coordinate in the far
    half of the tile (tile + 16 .. tile + 32: they all have one exponent). Per line the value at the first
    pixel of the triangle (xs; see span_start) is C + floor(A xs) + floor(B y), and every further pixel adds A
    rounded down to the grid. The result is cut down to 16 bits."""
    if attr is not None:
        cfg = {**cfg, "constant sum order": cfg["tsp attribute constant sum order"]}
    if xs is None:
        xs = span_start(cfg, x, y, px, py)
    a, b, c, inv = setup_raw(cfg, x, y, val, attr)
    CP = cfg["coefficient product"]
    with np.errstate(all="ignore"):
        A = rnd(rnd(a * inv, CP), cfg["tsp slope coefficient"])
        B = rnd(rnd(b * inv, CP), cfg["tsp slope coefficient"])
        C = rnd(rnd(c * inv, CP), cfg["tsp constant coefficient"])
        ex_x = tsp_exp(np.floor(px / 32) * 32 + 16)
        ex_y = tsp_exp(np.floor(py / 32) * 32 + 16)
        E = np.maximum(tsp_exp(C), np.maximum(tsp_exp(A) + ex_x - 1, tsp_exp(B) + ex_y - 1))
        E = np.where(E < -5000, 0, E)                  # a plane that is zero everywhere: any grid
        lsb = np.ldexp(1.0, E - cfg["tsp line grid"][0])
        v = floor_to(C, lsb) + floor_to(A * xs, lsb) + floor_to(B * py, lsb) + floor_to(A, lsb) * (px - xs)
        return floor_bits(v, cfg["tsp value"][0])


# The reciprocal of the TSP, read off a console for all 32768 16 bit divisor mantissas (pvr_tests/uvmeas, mix
# recipscan): a table over the top 9 bits below the leading one, t[i] = ceil(2^32 / (64 i)) in half units, and a
# linear step over the low 6 bits with slope (t[i] - t[i+1] + c[i]) / 128. The digits c[i] are measured.
RECIP_C = ("0111111111111111111111111011011111111111111110111101100100111111"
           "1110011111110011101011111111101111111110110111111111121010111111"
           "1011111111001111111111111101111101110101111111001111111111001101"
           "0111111111111111111210111110100101111111111001110001111111001111"
           "1111111111111011011110111001111210001111001111111122100011111111"
           "0110010110100011110100011111011110111111110100011111111121110001"
           "0111111111011111111111011111111111111211001110100110100111111111"
           "1011101101111111111110111010111110111111001100111111111111111110")
RECIP_T = np.array([-(-(1 << 32) // (64 * i)) for i in range(512, 1025)], dtype=np.int64)
RECIP_N = (RECIP_T[:-1] - RECIP_T[1:]) + np.array([int(ch) for ch in RECIP_C], dtype=np.int64)


def tsp_recip_mantissa(D):
    """The 16 bit reciprocal (32768..65535, a fraction of 65536 in [0.5, 1)) of a 16 bit mantissa D (32768..65535)."""
    i = (D >> 6) - 512
    return (64 * RECIP_T[i] - 1 - RECIP_N[i] * (D & 63)) >> 7


def tsp_divide(num, den):
    """num / den as the TSP does it, both 16 bit floats: num times the table reciprocal of den, the product of the
    two mantissas cut down (toward minus infinity) at 17 fractional bits and not normalized before the cut.
    (A divisor that is zero, negative or not finite is not measured: plain division.)"""
    num, den = np.asarray(num, dtype=np.float64), np.asarray(den, dtype=np.float64)
    with np.errstate(all="ignore"):
        plain = ~np.isfinite(num) | ~np.isfinite(den) | (den <= 0) | (num == 0)
        mn, en = np.frexp(np.where(plain, 1.0, num))
        md, ed = np.frexp(np.where(plain, 1.0, den))
        D = np.clip(np.floor(md * 65536), 32768, 65535).astype(np.int64)
        r = tsp_recip_mantissa(D) / 65536.0
        return np.where(plain, num / den, np.ldexp(np.floor(mn * r * 131072.0) / 131072.0, en + 1 - ed))


def fog_readout(iw):
    """What the tspw / wmeas / ops fog setup shows for a TSP 1/w: black polygon, white fog, every table pair (0, 255)."""
    w = np.clip(iw, 1.0, 255.999985).astype(np.float32)
    bf = (w.view(np.uint32) >> 11) & 255
    alpha = (255 * bf) >> 8
    return ((255 * alpha) >> 8).astype(int)


def tsp_attr(cfg, x, y, z, val, px, py):
    """An attribute (texture coordinate, color component; (N, 3) per vertex) at the pixel, as a number."""
    num = tsp_plane(cfg, x, y, z, px, py, attr=val)
    den = tsp_plane(cfg, x, y, z, px, py)
    with np.errstate(all="ignore"):
        return tsp_divide(num, den)


def tsp_color(cfg, x, y, z, col, px, py):
    """A Gouraud color (0..255 per vertex, (N, 3)) at the pixel."""
    v = tsp_attr(cfg, x, y, z, col, px, py)
    with np.errstate(all="ignore"):
        return np.clip(np.floor(v + cfg["tsp color round"][0]), 0, 255).astype(int)


def edge_values(cfg, xa, ya, xb, yb, px, py, half=0.5):
    """The edge function dx * Y - dy * X + c of the edge a -> b in the tile of the pixel (px, py), as the ISP holds
    it: S, its value at the first pixel of the tile; sx, sy, its steps per column and per row; all three in units
    of G = 2^(E - 27); i, j, the column and the row of the pixel in the tile; G itself.

      - c = xb ya - xa yb, the constant the depth setup uses too
      - the value at the tile's first pixel center is (dx y0 - dy x0) + c in 24 bit arithmetic. In the first sum an
        operand whose exponent is "edge add reach" (25) or more below the other's is dropped: it is beyond the
        adder's alignment shift (seen in the first column and the first row of tiles, where x0 or y0 is 0.5)
        The start value saturates: when the sum dx y0 - dy x0, or the start itself, reaches 2^128, the start
        is 2^127 with the sign of what overflowed; c itself may be far larger (pvr_tests/hugepos: corners at
        2^118 to 2^124)
      - that value is kept as a 20 bit float; dx and dy as 20 bit floats, cut to 21 bits under the exponent of
        the larger
      - E is the exponent of the larger slope plus 6, or that of the start value plus 1 if that is more."""
    EP, EC, CD = cfg["edge product"], cfg["edge constant"], cfg["coordinate difference"]
    XP, YP, ES = cfg["edge x product"], cfg["edge y product"], cfg["edge sum"]
    x0, y0 = np.floor((px - half) / 32) * 32 + half, np.floor((py - half) / 32) * 32 + half
    ex = lambda v: np.where(v == 0, -9999, np.frexp(v)[1])
    cut = lambda v, lsb: np.trunc(v / lsb) * lsb
    MB, D = cfg["edge mantissa"], cfg["edge add reach"][0]
    with np.errstate(all="ignore"):
        c = rnd(rnd(xb * ya, EP) - rnd(xa * yb, EP), EC)
        dx, dy = rnd(xa - xb, CD), rnd(ya - yb, CD)
        t1, t2 = rnd(dx * y0, XP), -rnd(dy * x0, YP)
        e1, e2 = ex(t1), ex(t2)
        first = np.where(e1 - e2 >= D, t1, np.where(e2 - e1 >= D, t2, rnd(t1 + t2, ES)))
        # the start value saturates: when the sum, or the start itself, reaches 2^128 it becomes 2^127 with
        # the sign of what overflowed. c has a wider range (25 * 2^240 is fine).
        over = np.abs(first) >= 2.0 ** 128
        start = rnd(np.where(over, 0.0, first) + c, ES)
        start = np.where(over, np.sign(first) * 2.0 ** 127, np.where(np.abs(start) >= 2.0 ** 128, np.sign(start) * 2.0 ** 127, start))
        ep = np.maximum(ex(dx), ex(dy))
        E = np.maximum(ep + cfg["edge block exponent"][0], ex(start) + 1)
        E = np.where(E < -5000, 0, E)
        G = np.ldexp(1.0, E - cfg["edge unit"][0] - 7)
        lp = np.ldexp(1.0, np.where(ep < -5000, 0, ep) - cfg["edge slope pair grid"][0])
        return rnd(start, MB) / G, -cut(rnd(dy, MB), lp) / G, cut(rnd(dx, MB), lp) / G, px - x0, py - y0, G


def covered(cfg, x, y, px, py, half=0.5, rows=True):
    """Whether the pixel sampled at (px, py) is inside the triangle (rasterizer order, no culling). x, y: (N, 3),
    or (N, 4) for a sprite: its four corners in order, the winding taken from the first three. half: 0.5 when
    the ISP samples at pixel centers (HALF_OFFSET bit 0, the default), 0 when it samples at their corners.
    rows: False for a modifier volume triangle, which has no row range (below).

    Per edge, with the values of edge_values turned so that inside is positive (pvr_tests/covmeas):
      - ZERO is a value of at most Z = 64 G: half a unit of the 20th bit under E.
      - R = S + j sy is the value of the row at the tile's first column. If R is zero, the whole row of the tile
        is decided at once, as the top-left rule would for an edge through the pixel centers: by the sign of the
        column step, or, when that is zero as well (at most Z), by the sign of the row step. The pixels are not
        looked at: a nearly horizontal edge is in or out along the whole row of the tile, however far it leans.
      - otherwise the pixel's value v = R + i sx decides by its sign; a pixel whose value is zero is inside when
        the value of the NEXT pixel to its right is not negative (zero included). The last pixel of the tile has
        no next one: there the sign of the column step decides.
    A left edge so takes its tie pixels and a right edge does not; but a tie pixel of an edge that leans less
    than Z per pixel is inside whichever way it leans, as long as the next pixel is not below zero.
    The winding is the sign of the setup's determinant, zero counting as positive.
    An edge between two equal corners is zero everywhere and counts as inside: a triangle of three equal corners
    fills the width of its tile on the rows of its row range (the hardware's degenerate-triangle bug; with any
    culling mode but "none" such a triangle is culled first)."""
    X1, X2, X3 = x[:, 0], x[:, 1], x[:, 2]
    Y1, Y2, Y3 = y[:, 0], y[:, 1], y[:, 2]
    # the winding: the sign of the setup's determinant (twice the area, from the three edge constants). The
    # exact area can be zero or of the other sign when a corner is huge; the console goes by this one
    # (pvr_tests/hugepos)
    EP, EC = cfg["edge product"], cfg["edge constant"]
    with np.errstate(all="ignore"):
        e1 = rnd(rnd(X2 * Y3, EP) - rnd(X3 * Y2, EP), EC)
        e2 = rnd(rnd(X3 * Y1, EP) - rnd(X1 * Y3, EP), EC)
        e3 = rnd(rnd(X1 * Y2, EP) - rnd(X2 * Y1, EP), EC)
        area = add3(e1, e2, e3, cfg["determinant sum order"], cfg["determinant sum"])
    sgn = np.where(area >= 0, -1.0, 1.0)      # a determinant of zero counts as positive (covmeas, mix sliver)
    Z = cfg["edge zero"][0]

    def edge(xa, ya, xb, yb):
        S, sx, sy, i, j, _ = edge_values(cfg, xa, ya, xb, yb, px, py, half)
        with np.errstate(all="ignore"):
            S, sx, sy = sgn * S, sgn * sx, sgn * sy
            R = S + sy * j
            v = R + sx * i
            # sy >= 0: an edge between two equal corners has no steps and no value, and counts as inside
            row = np.where(np.abs(sx) <= cfg["edge tie step"][0], sy >= 0, sx > 0)
            pixel = np.where(np.abs(v) <= Z, np.where(i == 31, sx > 0, v + sx >= -Z), v > Z)
        return np.where(np.isfinite(v), np.where(np.abs(R) <= Z, row, pixel), False)

    K = x.shape[1]
    # The rows a polygon is rasterized on: from the row its top corner is in to the row of its bottom corner's
    # y + 0.5, the same with either sample offset. Ordinary polygons never notice; a sliver's truncated edge
    # functions accept pixels beyond its ends, and those rows are cut off. The depth is not written there
    # either: it is the ISP's limit (covmeas, mix sliver, --prim zprobe). Modifier volume triangles have none.
    row = np.floor(py - half)
    inside = (row >= np.floor(y.min(axis=1))) & (row <= np.floor(y.max(axis=1) + 0.5)) if rows else np.ones(len(px), bool)
    for k in range(K):
        inside &= edge(x[:, k], y[:, k], x[:, (k + 1) % K], y[:, (k + 1) % K])
    return inside


def alternatives():
    """(operation, description, config) for every single-operation change worth testing."""
    out = []
    for name, (bits, mode) in BASE.items():
        if mode == "order":
            for alt in ("12,3", "13,2", "23,1"):
                if alt != bits:
                    out.append((name, f"({alt[0]} + {alt[1]}) + {alt[3]}", {**BASE, name: (alt, "order")}))
            continue
        if mode == "floor":
            for d in (-2, -1, 1, 2):
                out.append((name, f"{bits + d} bits", {**BASE, name: (bits + d, mode)}))
            continue
        if mode == "exp":
            for d in (-1, 1):
                out.append((name, f"{bits + d:+d}", {**BASE, name: (bits + d, mode)}))
            continue
        if mode == "level":
            for alt in (bits - 1, bits + 1, bits // 2, bits * 2):
                out.append((name, f"{alt}", {**BASE, name: (alt, mode)}))
            continue
        if mode == "bias":
            for b in (0.5, 0.49, 0.0):
                out.append((name, f"bias {b}", {**BASE, name: (b, "bias")}))
            continue
        for d in (-2, -1, 1, 2):
            if bits + d <= 30:
                out.append((name, f"{bits + d} bits", {**BASE, name: (bits + d, mode)}))
        for m in ("nearest", "floor", "ceil"):
            out.append((name, m, {**BASE, name: (bits, m)}))
    return out
